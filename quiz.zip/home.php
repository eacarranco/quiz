<?php
include 'auth.php';
include 'db_connect.php';
$title = 'Inicio';
include 'header_adminlte.php';
?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fa fa-list"></i> Cuestionarios disponibles</h5>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="quizTable" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <?php if ($_SESSION['login_user_type'] == 3): ?>
                                <th>Cuestionario</th>
                                <th style="width: 15%">Preguntas</th>
                                <th style="width: 15%">Intentos</th>
                            <?php else: ?>
                                <th style="width: 5%">#</th>
                                <th>Cuestionario</th>
                                <th style="width: 15%">Preguntas</th>
                                <th style="width: 15%">Completados</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $where = '';
                        if ($_SESSION['login_user_type'] == 2) { // Faculty
                            $where = " where u.id = " . $_SESSION['login_id'] . " ";
                        }
                        if ($_SESSION['login_user_type'] == 3) { // Student
                            $where = " where q.id in (SELECT quiz_id from quiz_student_list where user_id = '" . $_SESSION['login_id'] . "') ";
                        }
                        $qry = $conn->query("SELECT q.*, u.name as fname from quiz_list q left join users u on q.user_id = u.id " . $where . " order by q.title asc ");
                        $i = 1;
                        if ($qry->num_rows > 0) {
                            while ($row = $qry->fetch_assoc()) {
                                if ($_SESSION['login_user_type'] == 3) { // Student View
                                    $items = $conn->query("SELECT count(id) as item_count from questions where qid = '" . $row['id'] . "' ")->fetch_array()['item_count'];
                                    $attempts = $conn->query("SELECT count(distinct id) as attempt_count from history where quiz_id = '" . $row['id'] . "' and user_id = '" . $_SESSION['login_id'] . "'")->fetch_array()['attempt_count'];
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['title']) ?></td>
                                        <td><span class="badge badge-info"><?php echo $items ?></span></td>
                                        <td><span class="badge badge-primary"><?php echo $attempts ?></span></td>                                        
                                    </tr>
                                    <?php
                                } else { // Faculty View
                                    $items = $conn->query("SELECT count(id) as item_count from questions where qid = '" . $row['id'] . "' ")->fetch_array()['item_count'];
                                    $taken = $conn->query("SELECT count(id) as item_count from history where quiz_id = '" . $row['id'] . "'")->fetch_array()['item_count'];
                                    ?>
                                    <tr>
                                        <td><?php echo $i++ ?></td>
                                        <td><strong><?php echo htmlspecialchars($row['title']) ?></strong></td>
                                        <td><span class="badge badge-info"><?php echo $items ?></span></td>
                                        <td><span class="badge badge-primary"><?php echo $taken ?></span></td>                                        
                                    </tr>
                                    <?php
                                }
                            }
                        } else {
                            $colspan = ($_SESSION['login_user_type'] == 3 || $_SESSION['login_user_type'] == 1) ? 4: 3;
                            //echo '<tr><td colspan="'.$colspan.'" class="text-center text-muted">No hay cuestionarios disponibles</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<script>
    $(function () {
        // Inicializar DataTable con validación
        function initializeQuizTable() {
            // Destruir tabla anterior si existe
            if ($.fn.dataTable.isDataTable('#quizTable')) {
                $('#quizTable').DataTable().destroy();
            }
            
            // Inicializar DataTable
            $('#quizTable').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": false,
                "order": [[1, "asc"]],
                "columnDefs": [
                    { "orderable": false, "targets": -1 }  // Deshabilitar ordenamiento en última columna
                ],
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
                }
            });
        }
        
        // Inicializar cuando el DOM esté listo
        initializeQuizTable();
    });
</script>
<?php include('footer_adminlte.php'); ?>