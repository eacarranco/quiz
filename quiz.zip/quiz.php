<?php
    include ('auth.php');
    include ('db_connect.php');
    $title = 'Gestión de Cuestionarios';
    include ('header_adminlte.php');
?>

<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Listado de Cuestionarios</h3>
				<div class="card-tools">
					<button class="btn btn-primary btn-sm" id="new_quiz"><i class="fa fa-plus"></i> Agregar Cuestionario</button>
				</div>
			</div>
			<div class="card-body">
				<table class="table table-bordered table-striped" id='table'>
					<thead>
						<tr>
						<th style="width: 5%; text-align: center;">#</th>
						<th style="width: 25%;"><i class="fa fa-pencil"></i> Título</th>
						<th style="width: 12%; text-align: center;"><i class="fa fa-question"></i> Preguntas</th>
						<th style="width: 12%; text-align: center;"><i class="fa fa-star"></i> Puntos/Preg</th>
						<?php if($_SESSION['login_user_type'] ==1): ?>
						<th style="width: 20%;"><i class="fa fa-tag"></i> Tema</th>
						<?php endif; ?>
						<th style="<?php echo $_SESSION['login_user_type'] ==1 ? 'width: 26%;' : 'width: 46%;'; ?> text-align: center;"><i class="fa fa-cogs"></i> Acciones</th>
						</tr>
					</thead>
					<tbody>
					<?php
        					$where = '';
        					if($_SESSION['login_user_type'] == 2){
        						$where = " where u.id = ".$_SESSION['login_id']." ";
        					}
        					$qry = $conn->query("SELECT q.*,u.name as fname from quiz_list q left join users u on q.user_id = u.id ".$where." order by q.title asc ");
        					$i = 1;
        					if($qry->num_rows > 0){
        						while($row= $qry->fetch_assoc()){
        							$items = $conn->query("SELECT count(id) as item_count from questions where qid = '".$row['id']."' ")->fetch_array()['item_count'];
        				?>
				<tr>
					<td style="text-align: center; vertical-align: middle;"><strong><?php echo $i++ ?></strong></td>
					<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['title']) ?></td>
					<td style="text-align: center; vertical-align: middle;"><span class="badge badge-info"><?php echo $items ?></span></td>
					<td style="text-align: center; vertical-align: middle;"><span class="badge badge-success"><?php echo $row['qpoints'] ?></span></td>
					<?php if($_SESSION['login_user_type'] ==1): ?>
					<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['fname']) ?></td>
					<?php endif; ?>
					<td style="text-align: center; vertical-align: middle;">
						<a class="btn btn-sm btn-primary" href="./quiz_view.php?id=<?php echo $row['id']?>">
							<i class="fa fa-cog"></i> Administrar
						</a>
						<button class="btn btn-sm btn-warning edit_quiz" data-id="<?php echo $row['id'] ?>" type="button">
							<i class="fa fa-edit"></i> Editar
						</button>
						<button class="btn btn-sm btn-danger remove_quiz" data-id="<?php echo $row['id']?>" type="button">
							<i class="fa fa-trash"></i> Eliminar
						</button>
					</td>
				</tr>
					<?php
					}
					} else {
						//echo '<tr><td colspan="6" style="text-align: center; padding: 20px;" class="text-muted">No hay cuestionarios registrados</td></tr>';
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal Gestionar Cuestionario -->
	<div class="modal fade" id="manage_quiz" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="myModallabel">Crear Nuevo Cuestionario</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form id='quiz-frm'>
					<div class="modal-body">
						<div id="msg"></div>
						<div class="form-group">
							<label>Título del Cuestionario</label>
							<input type="hidden" name="id" />
							<input type="text" name="title" required class="form-control" placeholder="Ingrese título" />
						</div>
						<div class="form-group">
							<label>Puntos por Pregunta</label>
							<input type="number" name="qpoints" required class="form-control" placeholder="Ej: 1" />
						</div>					<div class="form-group">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" name="randomize_options" id="randomize_options" value="1" checked>
							<label class="custom-control-label" for="randomize_options">
								Mostrar respuestas de forma aleatoria
							</label>
						</div>
						<small class="form-text text-muted">
							Si está marcado, las respuestas se mostrarán en orden aleatorio. Si no, se mostrarán en el orden ingresado.
						</small>
					</div>						<?php if($_SESSION['login_user_type'] == 1): ?>
						<div class="form-group">
							<label>Tema/Profesor</label>
							<select name="user_id" required class="form-control">
								<option value="">Seleccione un Tema</option>
								<?php
									$qry = $conn->query("SELECT * from users where user_type = 2 order by name asc");
									while($row= $qry->fetch_assoc()){
								?>
									<option value="<?php echo $row['id'] ?>"><?php echo htmlspecialchars($row['name']) ?></option>
								<?php } ?>
							</select>
						</div>
						<?php else: ?>
							<input type="hidden" name="user_id" />
						<?php endif; ?>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
						<button type="submit" class="btn btn-primary" name="save">
							<i class="fa fa-save"></i> Guardar
						</button>
					</div>
		</div>
	</div>
</div>

<script>
	// Inicializar DataTable
	function initializeDataTable() {
		if ($.fn.dataTable.isDataTable('#table')) {
			$('#table').DataTable().destroy();
		}
		$('#table').DataTable({
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": false,
			"order": [[1, "asc"]],
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
			}
		});
	}

	$(function(){
		initializeDataTable();
		$(document).on('click', '#new_quiz', function(){
			$('#msg').html('')
			$('#manage_quiz .modal-title').html('Crear Nuevo Cuestionario')
			$('#manage_quiz #quiz-frm').get(0).reset()
			$('#manage_quiz').modal('show')
		})
		$(document).on('click', '.edit_quiz', function(){
			var id = $(this).attr('data-id')
			$.ajax({
				url:'./get_quiz.php?id='+id,
				error:err=>console.log(err),
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						$('[name="id"]').val(resp.id)
						$('[name="title"]').val(resp.title)
						$('[name="qpoints"]').val(resp.qpoints)
						$('[name="user_id"] ').val(resp.user_id)
						// Manejar el checkbox de aleatorización
						if(resp.randomize_options == 1){
							$('[name="randomize_options"]').prop('checked', true)
						} else {
							$('[name="randomize_options"]').prop('checked', false)
						}
						$('#manage_quiz .modal-title').html('Editar Cuestionario')
						$('#manage_quiz').modal('show')
					}
				}
			})
		})
		$(document).on('click', '.remove_quiz', function(){
			var id = $(this).attr('data-id')
			if(confirm('¿Está seguro que desea eliminar este cuestionario?')){
				$.ajax({
					url:'./delete_quiz.php?id='+id,
					error:err=>console.log(err),
					success:function(resp){
						if(resp == true)
							location.reload()
					}
				})
			}
		})
		$('#quiz-frm').submit(function(e){
			e.preventDefault();
			$('#quiz-frm [name="save"]').attr('disabled',true)
			$('#quiz-frm [name="save"]').html('<i class="fa fa-spinner fa-spin"></i> Guardando...')
			$('#msg').html('')

			$.ajax({
				url:'./save_quiz.php',
				method:'POST',
				data:$(this).serialize(),
				error:err=>{
					console.log(err)
					alert('Ocurrió un error')
					$('#quiz-frm [name="save"]').removeAttr('disabled')
					$('#quiz-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
				},
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						if(resp.status == 1){
							alert('Cuestionario guardado correctamente');
							location.replace('./quiz_view.php?id='+resp.id)
						}else{
							$('#msg').html('<div class="alert alert-danger">'+resp.msg+'</div>')
							$('#quiz-frm [name="save"]').removeAttr('disabled')
							$('#quiz-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
						}
					}
				}
			})
		})
	})
</script>
<?php include('footer_adminlte.php'); ?>