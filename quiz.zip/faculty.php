<?php
    include ('auth.php');
    include ('db_connect.php');
    $title = 'Gestión de Temas/Profesores';
    include ('header_adminlte.php');
?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Listado de Temas</h3>
                <div class="card-tools">
                    <button class="btn btn-primary btn-sm" id="new_faculty"><i class="fa fa-plus"></i> Agregar Tema</button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="table" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th style="width: 5%; text-align: center;">#</th>
							<th style="width: 35%;"><i class="fa fa-user"></i> Profesor</th>
							<th style="width: 30%;"><i class="fa fa-book"></i> Tema</th>
							<th style="width: 30%; text-align: center;"><i class="fa fa-cogs"></i> Acciones</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$qry = $conn->query("SELECT f.*,u.name from faculty f left join users u  on f.user_id = u.id order by u.name asc ");
					$i = 1;
					if($qry->num_rows > 0){
						while($row= $qry->fetch_assoc()){
						?>
					<tr>
						<td style="text-align: center; vertical-align: middle;"><strong><?php echo $i++ ?></strong></td>
						<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['name']) ?></td>
						<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['subject']) ?></td>
						<td style="text-align: center; vertical-align: middle;">
							 <button class="btn btn-sm btn-primary edit_faculty" data-id="<?php echo $row['id']?>" type="button">
							 	<i class="fa fa-edit"></i> Editar
							 </button>
							<button class="btn btn-sm btn-danger remove_faculty" data-id="<?php echo $row['id']?>" type="button">
								<i class="fa fa-trash"></i> Eliminar
							</button>
						</td>
					</tr>
					<?php
					}
					} else {
						//echo '<tr><td colspan="4" style="text-align: center; padding: 20px;" class="text-muted">No hay temas registrados</td></tr>';
					}
					?>
					</tbody>
				</table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<!-- Modal Gestionar Tema -->
<div class="modal fade" id="manage_faculty" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModallabel">Agregar Nuevo Tema</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id='faculty-frm'>
                <div class="modal-body">
                    <div id="msg"></div>
                    <div class="form-group">
                        <label>Nombre Profesor</label>
                        <input type="hidden" name="id" />
                        <input type="hidden" name="uid" />
                        <input type="hidden" name="user_type" value="2" />
                        <input type="text" name="name" required class="form-control" placeholder="Nombre completo" />
                    </div>
                    <div class="form-group">
                        <label>Tema/Asunto</label>
                        <input type="text" name="subject" required class="form-control" placeholder="Ej: Matemáticas, Física" />
                    </div>
                    <div class="form-group">
                        <label>Usuario</label>
                        <input type="text" name="username" required class="form-control" placeholder="Nombre de usuario" />
                    </div>
                    <div class="form-group">
                        <label>Contraseña</label>
                        <input type="password" name="password" required class="form-control" placeholder="Ingrese contraseña" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" name="save">
                        <i class="fa fa-save"></i> Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
	// Inicializar DataTable
	function initializeDataTable() {
		if ($.fn.dataTable.isDataTable('#table')) {
			$('#table').DataTable().destroy();
		}
		$('#table').DataTable({
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": false,
			"order": [[1, "asc"]],
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
			}
		});
	}

	$(function(){
		initializeDataTable();
		$(document).on('click', '#new_faculty', function(){
			$('#msg').html('')
			$('#manage_faculty .modal-title').html('Agregar Nuevo Tema')
			$('#manage_faculty #faculty-frm').get(0).reset()
			$('#manage_faculty').modal('show')
		})
		$(document).on('click', '.edit_faculty', function(){
			var id = $(this).attr('data-id')
			$.ajax({
				url:'./get_faculty.php?id='+id,
				error:err=>console.log(err),
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						$('[name="id"]').val(resp.id)
						$('[name="uid"]').val(resp.uid)
						$('[name="name"]').val(resp.name)
						$('[name="subject"]').val(resp.subject)
						$('[name="username"]').val(resp.username)
						$('[name="password"]').val(resp.password)
						$('#manage_faculty .modal-title').html('Editar Tema')
						$('#manage_faculty').modal('show')
					}
				}
			})
		})
		$(document).on('click', '.remove_faculty', function(){
			var id = $(this).attr('data-id')
			if(confirm('¿Está seguro que desea eliminar este tema?')){
				$.ajax({
					url:'./delete_faculty.php?id='+id,
					error:err=>console.log(err),
					success:function(resp){
						if(resp == true)
							location.reload()
					}
				})
			}
		})
		$('#faculty-frm').submit(function(e){
			e.preventDefault();
			$('#faculty-frm [name="save"]').attr('disabled',true)
			$('#faculty-frm [name="save"]').html('<i class="fa fa-spinner fa-spin"></i> Guardando...')
			$('#msg').html('')

			$.ajax({
				url:'./save_faculty.php',
				method:'POST',
				data:$(this).serialize(),
				error:err=>{
					console.log(err)
					alert('Ocurrió un error')
					$('#faculty-frm [name="save"]').removeAttr('disabled')
					$('#faculty-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
				},
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						if(resp.status == 1){
							alert('Tema guardado correctamente');
							location.reload()
						}else{
							$('#msg').html('<div class="alert alert-danger">'+resp.msg+'</div>')
							$('#faculty-frm [name="save"]').removeAttr('disabled')
							$('#faculty-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
						}
					}
				}
			})
		})
	})
</script>
<?php include('footer_adminlte.php'); ?>