-- Agregar columna para controlar si las respuestas deben ser aleatorias
ALTER TABLE `quiz_list` ADD COLUMN `randomize_options` TINYINT(1) NOT NULL DEFAULT 1 AFTER `qpoints`;
