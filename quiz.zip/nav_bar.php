			<nav class="navbar-header">
			<div class="container-fluid d-flex justify-content-between align-items-center">
				<div class="navbar-brand">
					<p class="navbar-text text-white m-0" style="font-size: 18px;"><strong>Cuestionarios DINARP</strong></p>
				</div>
				<div class="nav navbar-nav ml-auto">
					<a href="logout.php" class="text-white" style="text-decoration: none; display: flex; align-items: center;"><span style="margin-right: 8px;"><?php echo $name ?></span><i class="fa fa-power-off"></i></a>
				</div>
			</div>
		</nav>
		<div id="sidebar" class="bg-dark">
			<div id="sidebar-field">
				<a href="home.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-home"></i></div>  Inicio
				</a>
			</div>
			<?php if($_SESSION['login_user_type'] != 3): ?>
			<?php if($_SESSION['login_user_type'] == 1): ?>
			<div id="sidebar-field">
				<a href="faculty.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-users"></i></div>  Cursos
				</a>
			</div>
		<?php endif; ?>
			<div id="sidebar-field">
				<a href="student.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-users"></i></div>  Estudiantes
				</a>
			</div>
			<div id="sidebar-field">
				<a href="quiz.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-list"></i></div>  Cuestionarios
				</a>
			</div>
			<div id="sidebar-field">
				<a href="history.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-history"></i></div>  Historial
				</a>
			</div>
			<?php else: ?>
			<div id="sidebar-field">
				<a href="student_quiz_list.php" class="sidebar-item text-white">
						<div class="sidebar-icon"><i class="fa fa-list"></i></div>  Mis Cuestionarios
				</a>
			</div>
		<?php endif; ?>

		</div>
		<script>
			$(document).ready(function(){
				var loc = window.location.href;
				loc.split('{/}')
				$('#sidebar a').each(function(){
				// console.log(loc.substr(loc.lastIndexOf("/") + 1),$(this).attr('href'))
					if($(this).attr('href') == loc.substr(loc.lastIndexOf("/") + 1)){
						$(this).addClass('active')
					}
				})
			})
			
		</script>