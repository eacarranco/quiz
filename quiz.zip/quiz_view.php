<?php
include('auth.php');
include('db_connect.php');
$qry = $conn->query("SELECT * FROM quiz_list where id = " . $_GET['id'])->fetch_array();
$title = htmlspecialchars($qry['title']);
include('header_adminlte.php');
?>

<div class="row">
	<div class="col-md-6">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Preguntas</h3>
				<div class="card-tools">
					<button class="btn btn-primary btn-sm" id="new_question"><i class="fa fa-plus"></i> Agregar
						Pregunta</button>
				</div>
			</div>
			<div class="card-body">
				<ul class="list-group">
					<?php
					$cont = 0;
					$qry = $conn->query("SELECT * FROM questions where qid = " . $_GET['id'] . " order by id asc");
					while ($row = $qry->fetch_array()) {
						$cont++;
						?>
						<li class="list-group-item"><?php echo $cont . '. ' . $row['question'] ?><br>
							<center>
								<button class="btn btn-sm btn-outline-primary edit_question"
									data-id="<?php echo $row['id'] ?>" type="button"><i class="fa fa-edit"></i></button>
								<button class="btn btn-sm btn-outline-danger remove_question"
									data-id="<?php echo $row['id'] ?>" type="button"><i class="fa fa-trash"></i></button>
							</center>
						</li>
						<?php
					}
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Estudiantes</h3>
				<div class="card-tools">
					<button class="btn btn-primary btn-sm" id="new_student"><i class="fa fa-plus"></i> Agregar
						Estudiante</button>
				</div>
			</div>
			<div class="card-body">
				<ul class="list-group">
					<?php
					$qry = $conn->query("SELECT u.*,q.id as qid FROM users u left join quiz_student_list q on u.id = q.user_id where q.quiz_id = " . $_GET['id'] . " order by u.name asc");
					while ($row = $qry->fetch_array()) {
						?>
						<li class="list-group-item d-flex justify-content-between align-items-center">
							<?php echo ucwords($row['name']) ?>
							<button class="btn btn-sm btn-outline-danger remove_student" data-id="<?php echo $row['id'] ?>"
								data-qid='<?php echo $row['qid'] ?>' type="button"><i class="fa fa-trash"></i></button>
						</li>
						<?php
					}
					?>
				</ul>
			</div>
		</div>
	</div>
</div>

<!-- Modal Gestionar Pregunta -->
<div class="modal fade" id="manage_question" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">

				<h4 class="modal-title" id="myModallabel"> Nueva Pregunta</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
			</div>
			<form id='question-frm'>
			<div class="modal-body">
				<div id="msg"></div>
				<div class="form-group">
					<label>Pregunta</label>
					<input type="hidden" name="qid" value="<?php echo $_GET['id'] ?>" />
					<input type="hidden" name="id" />
					<textarea rows='3' name="question" required="required" class="form-control"></textarea>
				</div>
				<label><strong>Opciones de Respuesta:</strong></label>
				<div id="error-msg" class="alert alert-danger" style="display:none;"></div>

				<div class="form-group">
					<!-- Opción A -->
					<div class="form-group mb-3 p-2" style="border: 1px solid #e9ecef; border-radius: 4px;">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<input type="radio" name="is_right" value="0" aria-label="Respuesta correcta A">
								</div>
							</div>
							<textarea rows="2" name="question_opt[0]" required class="form-control" placeholder="Opción A">(+) </textarea>
						</div>
						<small class="form-text text-muted">Opción A</small>
					</div>

					<!-- Opción B -->
					<div class="form-group mb-3 p-2" style="border: 1px solid #e9ecef; border-radius: 4px;">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<input type="radio" name="is_right" value="1" aria-label="Respuesta correcta B">
								</div>
							</div>
							<textarea rows="2" name="question_opt[1]" required class="form-control" placeholder="Opción B">(-)</textarea>
						</div>
						<small class="form-text text-muted">Opción B</small>
					</div>

					<!-- Opción C -->
					<div class="form-group mb-3 p-2" style="border: 1px solid #e9ecef; border-radius: 4px;">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<input type="radio" name="is_right" value="2" aria-label="Respuesta correcta C">
								</div>
							</div>
							<textarea rows="2" name="question_opt[2]" required class="form-control" placeholder="Opción C">(-)</textarea>
						</div>
						<small class="form-text text-muted">Opción C</small>
					</div>

					<!-- Opción D -->
					<div class="form-group mb-3 p-2" style="border: 1px solid #e9ecef; border-radius: 4px;">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<input type="radio" name="is_right" value="3" aria-label="Respuesta correcta D">
								</div>
							</div>
							<textarea rows="2" name="question_opt[3]" required class="form-control" placeholder="Opción D">(+) </textarea>
						</div>
						<small class="form-text text-muted">Opción D</small>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
				<button type="submit" class="btn btn-primary" name="save"><i class="fa fa-save"></i> Guardar</button>
			</div>
		</form>
		</div>
	</div>
</div>

<div class="modal fade" id="manage_student" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">

				<h4 class="modal-title" id="myModallabel">Agregar nuevo estudiante/s</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
			</div>
			<form id='student-frm'>
				<div class="modal-body">
					<div id="msg"></div>
					<div class="form-group">
						<label>Student/s</label>
						<br>
						<input type="hidden" name="qid" value="<?php echo $_GET['id'] ?>" />
						<select rows='3' name="user_id[]" required="required" multiple class="form-control select2"
							style="width: 100% !important">
							<?php
							$student = $conn->query('SELECT u.*,s.level_section as ls FROM users u left join students s on u.id = s.user_id where u.user_type = 3 ');
							while ($row = $student->fetch_assoc()) {

								?>
								<option value="<?php echo $row['id'] ?>"><?php echo ucwords($row['name']) . ' ' . $row['ls'] ?>
								</option>
							<?php } ?>
						</select>

						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-primary" name="save"><i class="fa fa-save"></i> Guardar</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
	$(function () {
		$(".select2").select2({
			placeholder: "Seleccionar aquí",
			width: 'resolve'
		});
		// DataTable para lista de preguntas
		// (Las tablas en esta página son listas, no DataTables)
		$(document).on('click', '#new_question', function () {
			$('#msg').html('')
			$('#manage_question .modal-title').html('Agregar nueva pregunta')
			$('#manage_question #question-frm').get(0).reset()
			$('input[name="is_right"]').prop('checked', false)
			$('#error-msg').hide()
			$('#manage_question').modal('show')
		})
		$(document).on('click', '#new_student', function () {
			$('#msg').html('')
			$('#manage_student').modal('show')
		})
		$(document).on('click', '.edit_question', function () {
			var id = $(this).attr('data-id')
			$.ajax({
				url: './get_question.php?id=' + id,
				error: err => console.log(err),
				success: function (resp) {
					if (typeof resp != undefined) {
						resp = JSON.parse(resp)
						$('[name="id"]').val(resp.qdata.id)
						$('[name="question"]').val(resp.qdata.question)
						// Desmarcar todos los radio buttons
						$('input[name="is_right"]').prop('checked', false);
						
						Object.keys(resp.odata).map(k => {
							var data = resp.odata[k]
							$('[name="question_opt[' + k + ']"]').val(data.option_txt);
							// Comparar explícitamente como números para asegurar correctitud
							if (parseInt(data.is_right) === 1) {
								$('input[name="is_right"][value="' + k + '"]').prop('checked', true);
							}
						})
						$('#manage_question .modal-title').html('Editar Pregunta')
						$('#manage_question').modal('show')
						$('#error-msg').hide();

					}
				}
			})

		})
		$(document).on('click', '.remove_question', function () {
			var id = $(this).attr('data-id')
			var conf = confirm('Esta seguro de eliminar esta pregunta?');
			if (conf == true) {
				$.ajax({
					url: './delete_question.php?id=' + id,
					error: err => console.log(err),
					success: function (resp) {
						if (resp == true)
							location.reload()
					}
				})
			}
		})
		$(document).on('click', '.remove_student', function () {
			var qid = $(this).attr('data-qid')
			var conf = confirm('Esta seguro de eliminar el estudiante?');
			if (conf == true) {
				$.ajax({
					url: './delete_quiz_student.php?qid=' + qid,
					error: err => console.log(err),
					success: function (resp) {
						if (resp == true)
							location.reload()
					}
				})
			}
		})
		$('#question-frm').submit(function (e) {
			e.preventDefault();
			$('#error-msg').hide().html('');

			// Validar que la pregunta no esté vacía
			var question = $('[name="question"]').val().trim();
			if (!question) {
				$('#error-msg').html('<i class="fa fa-exclamation-circle"></i> La pregunta es requerida.').show();
				return false;
			}

			// Validar que todas las opciones tengan texto
			for (var i = 0; i < 4; i++) {
				var optText = $('[name="question_opt[' + i + ']"]').val().trim();
				if (!optText) {
					$('#error-msg').html('<i class="fa fa-exclamation-circle"></i> Todas las opciones de respuesta son requeridas.').show();
					return false;
				}
			}

			// Validar que una respuesta correcta esté seleccionada
			var selectedAnswer = $('input[name="is_right"]:checked').length;
			if (selectedAnswer === 0) {
				$('#error-msg').html('<i class="fa fa-exclamation-circle"></i> Debe seleccionar una respuesta correcta.').show();
				return false;
			}

			// Convertir los radio buttons al formato esperado por save_question.php
			// El valor seleccionado es el índice (0, 1, 2 o 3) del radio button marcado
			var correctIndex = parseInt($('input[name="is_right"]:checked').val());
			// Remover cualquier input hidden previo de is_right
			$('input[type="hidden"][name^="is_right"]').remove();
			// Agregar los inputs hidden con valores 1 o 0 según corresponda
			for (var i = 0; i < 4; i++) {
				var value = (i === correctIndex) ? '1' : '0';
				$('#question-frm').append('<input type="hidden" name="is_right[' + i + ']" value="' + value + '">');
			}

			$('#question-frm [name="save"]').attr('disabled', true);
			$('#question-frm [name="save"]').html('<i class="fa fa-spinner fa-spin"></i> Guardando...');

			$.ajax({
				url: './save_question.php',
				method: 'POST',
				data: $(this).serialize(),
				error: err => {
					console.log(err);
					$('#error-msg').html('<i class="fa fa-exclamation-circle"></i> Ocurrió un error al guardar.').show();
					$('#question-frm [name="save"]').removeAttr('disabled');
					$('#question-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar');
				},
				success: function (resp) {
					if (resp == 1) {
						alert('Información guardada correctamente.');
						location.reload();
					} else {
						$('#error-msg').html('<i class="fa fa-exclamation-circle"></i> Error al guardar la pregunta.').show();
						$('#question-frm [name="save"]').removeAttr('disabled');
						$('#question-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar');
					}
				}
			});
		})
		$('#student-frm').submit(function (e) {
			e.preventDefault();
			$('#student-frm [name="submit"]').attr('disabled', true)
			$('#student-frm [name="submit"]').html('Guardando...')
			$('#msg').html('')

			$.ajax({
				url: './quiz_student.php',
				method: 'POST',
				data: $(this).serialize(),
				error: err => {
					console.log(err)
					alert('An error occured')
					$('#student-frm [name="submit"]').removeAttr('disabled')
					$('#student-frm [name="submit"]').html('Guardar')
				},
				success: function (resp) {
					if (resp == 1) {
						alert('Información guardada correctamente.');
						location.reload()
					}
				}
			})
		})
	})
</script>
<?php include('footer_adminlte.php'); ?>