<?php 

include 'db_connect.php';

extract($_POST);

// Convertir checkbox a 1 o 0
$randomize_options = isset($randomize_options) && $randomize_options == 1 ? 1 : 0;

if(empty($id)){
	$data=  " title='".$title."'";
	$data .=  ", user_id='".$user_id."'";
	$data .=  ", qpoints='".$qpoints."'";
	$data .=  ", randomize_options='".$randomize_options."'";
	$insert_user = $conn->query('INSERT INTO quiz_list set  '.$data);

	if($insert_user){
			echo json_encode(array('status'=>1,'id'=>$conn->insert_id));
		
	}
}else{
	$data=  " title='".$title."'";
	$data .=  ", user_id='".$user_id."'";
	$data .=  ", qpoints='".$qpoints."'";
	$data .=  ", randomize_options='".$randomize_options."'";
	$update = $conn->query('UPDATE quiz_list set  '.$data.' where id= '.$id);

	if($update){
			echo json_encode(array('status'=>1,'id'=>$id));
		
	}
}