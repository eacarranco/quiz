<?php
    include ('auth.php');
    include ('db_connect.php');
    $title = 'Gestión de Estudiantes';
    include ('header_adminlte.php');
?>

<div class="row">
	<div class="col-12">
		<button class="btn btn-primary btn-sm mb-3" id="new_student">
			<i class="fa fa-plus"></i> Agregar Estudiante
		</button>
		
		<div class="card">
			<div class="card-header">
				<i class="fa fa-list"></i> Estudiantes Registrados
			</div>
			<div class="card-body">
				<table class="table table-bordered table-striped" id='table'>
					<thead>
						<tr>
							<th style="width: 5%; text-align: center;">#</th>
							<th style="width: 40%;"><i class="fa fa-user"></i> Nombre</th>
							<th style="width: 25%;"><i class="fa fa-graduation-cap"></i> Nivel</th>
							<th style="width: 30%; text-align: center;"><i class="fa fa-cogs"></i> Acciones</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$qry = $conn->query("SELECT s.*,u.name from students s left join users u  on s.user_id = u.id order by u.name asc ");
					$i = 1;
					if($qry->num_rows > 0){
						while($row= $qry->fetch_assoc()){
						?>
					<tr>
					<td style="text-align: center; vertical-align: middle;"><strong><?php echo $i++ ?></strong></td>
					<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['name']) ?></td>
					<td style="vertical-align: middle;"><?php echo htmlspecialchars($row['level_section']) ?></td>
					<td style="text-align: center; vertical-align: middle;">
						<button class="btn btn-sm btn-primary edit_student" data-id="<?php echo $row['id']?>" type="button">
							<i class="fa fa-edit"></i> Editar
						</button>
							<button class="btn btn-sm btn-danger remove_student" data-id="<?php echo $row['id']?>" type="button">
								<i class="fa fa-trash"></i> Eliminar
							</button>
						</td>
					</tr>
					<?php
					}
					} else {
						//echo '<tr><td colspan="4" style="text-align: center; padding: 20px;" class="text-muted">No hay estudiantes registrados</td></tr>';
					}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal Gestionar Estudiante -->
<div class="modal fade" id="manage_student" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="myModallabel">Agregar Estudiante</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form id='student-frm'>
					<div class="modal-body">
						<div id="msg"></div>
						<div class="form-group">
							<label>Nombre</label>
							<input type="hidden" name="id" />
							<input type="hidden" name="uid" />
							<input type="hidden" name="user_type" value="3" />
							<input type="text" name="name" required class="form-control" placeholder="Ingrese nombre completo" />
						</div>
						<div class="form-group">
							<label>Nivel/Grado</label>
							<input type="text" name="level_section" required class="form-control" placeholder="Ej: 10A, 11B" />
						</div>
						<div class="form-group">
							<label>Usuario</label>
							<input type="text" name="username" required class="form-control" placeholder="Nombre de usuario" />
						</div>
						<div class="form-group">
							<label>Contraseña</label>
							<input type="password" name="password" required class="form-control" placeholder="Ingrese contraseña" />
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
						<button type="submit" class="btn btn-primary" name="save">
							<i class="fa fa-save"></i> Guardar
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	// Inicializar DataTable
	function initializeDataTable() {
		if ($.fn.dataTable.isDataTable('#table')) {
			$('#table').DataTable().destroy();
		}
		$('#table').DataTable({
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": false,
			"order": [[1, "asc"]],
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
			}
		});
	}

	$(function(){
		initializeDataTable();
		$(document).on('click', '#new_student', function(){
			$('#msg').html('')
			$('#manage_student .modal-title').html('Agregar Nuevo Estudiante')
			$('#manage_student #student-frm').get(0).reset()
			$('#manage_student').modal('show')
		})
		$(document).on('click', '.edit_student', function(){
			var id = $(this).attr('data-id')
			$.ajax({
				url:'./get_student.php?id='+id,
				error:err=>console.log(err),
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						$('[name="id"]').val(resp.id)
						$('[name="uid"]').val(resp.uid)
						$('[name="name"]').val(resp.name)
						$('[name="level_section"]').val(resp.level_section)
						$('[name="username"]').val(resp.username)
						$('[name="password"]').val(resp.password)
						$('#manage_student .modal-title').html('Editar Estudiante')
						$('#manage_student').modal('show')
					}
				}
			})
		})
		$(document).on('click', '.remove_student', function(){
			var id = $(this).attr('data-id')
			if(confirm('¿Está seguro que desea eliminar este estudiante?')){
				$.ajax({
					url:'./delete_student.php?id='+id,
					error:err=>console.log(err),
					success:function(resp){
						if(resp == true)
							location.reload()
					}
				})
			}
		})
		$('#student-frm').submit(function(e){
			e.preventDefault();
			$('#student-frm [name="save"]').attr('disabled',true)
			$('#student-frm [name="save"]').html('<i class="fa fa-spinner fa-spin"></i> Guardando...')
			$('#msg').html('')

			$.ajax({
				url:'./save_student.php',
				method:'POST',
				data:$(this).serialize(),
				error:err=>{
					console.log(err)
					alert('Ocurrió un error')
					$('#student-frm [name="save"]').removeAttr('disabled')
					$('#student-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
				},
				success:function(resp){
					if(typeof resp != undefined){
						resp = JSON.parse(resp)
						if(resp.status == 1){
							alert('Estudiante guardado correctamente');
							location.reload()
						}else{
							$('#msg').html('<div class="alert alert-danger">'+resp.msg+'</div>')
							$('#student-frm [name="save"]').removeAttr('disabled')
							$('#student-frm [name="save"]').html('<i class="fa fa-save"></i> Guardar')
						}
					}
				}
			})
		})
	})
</script>
<?php include('footer_adminlte.php'); ?>